#' @param pol_degrees non-negative integer vector of polynomial 
#' degrees (orders).
