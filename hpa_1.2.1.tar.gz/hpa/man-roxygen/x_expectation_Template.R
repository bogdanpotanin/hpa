#' @param x non-negative numeric matrix of quantiles.
#' Note that \code{x} rows are observations while variables are columns.
