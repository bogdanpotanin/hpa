#' @param data data frame containing the variables in the model.
