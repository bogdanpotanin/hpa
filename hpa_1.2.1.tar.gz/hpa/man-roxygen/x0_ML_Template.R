#' @param x0 numeric vector of optimization routine initial values.
#' Note that \code{x0=c(pol_coefficients[-1], mean, sd)}. For 
#' \code{pol_coefficients}, \code{mean} and \code{sd} documentation 
#' see \code{\link[hpa]{dhpa}} function.
