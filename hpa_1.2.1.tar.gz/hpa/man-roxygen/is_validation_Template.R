#' @param is_validation logical value indicating whether function input 
#' arguments should be validated.  Set it to \code{FALSE} for slight
#' performance boost (default value is \code{TRUE}).
