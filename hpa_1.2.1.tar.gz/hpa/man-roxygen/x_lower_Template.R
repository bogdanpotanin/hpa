#' @param x_lower numeric matrix of lower integration limits.
#' Note that \code{x_lower} rows are observations while variables are columns.
