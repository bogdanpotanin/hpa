#' @param sd_fixed numeric value for binary choice equation random error
#' density \code{sd} parameter. Set it to \code{NA} (default) if this parameter
#' should be estimated rather than fixed.
