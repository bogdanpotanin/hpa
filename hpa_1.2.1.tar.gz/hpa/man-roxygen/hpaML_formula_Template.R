#' @details Let's use notations introduced in \code{\link[hpa]{dhpa}} 'Details' 
#' section. Function \code{\link[hpa]{hpaML}} maximizes the following
#' quasi log-likelihood function:
#' \deqn{\ln L(\alpha, \mu, \sigma; x) = \sum\limits_{i=1}^{n} 
#' \ln\left(f_{\xi}(x_{i};\alpha, \mu, \sigma)\right),}
#' 
#' where (in addition to previously defined notations):
#' 
#' \eqn{x_{i}} - are observations i.e. \code{data} matrix rows.
#' 
#' \eqn{n} - is sample size i.e. the number of \code{data} matrix rows.
#' 
#' Arguments \code{pol_degrees}, \code{tr_left}, \code{tr_right},
#' \code{given_ind} and \code{omit_ind} affect the form of 
#' \eqn{f_{\xi}\left(x_{i};\alpha, \mu, \sigma)\right)} in a way described in 
#' \code{\link[hpa]{dhpa}} 'Details' section. Note that change of
#' \code{given_ind} and \code{omit_ind} values may result in estimator which
#' statistical properties has not been rigorously investigated yet.
#' 
#' The first polynomial coefficient (zero powers) 
#' set to 1 for identification purposes i.e. \eqn{\alpha_{(0,...,0)}=1}.
#' 
#' All \code{NA} and \code{NaN} values will be removed from \code{data} matrix.
#' 
