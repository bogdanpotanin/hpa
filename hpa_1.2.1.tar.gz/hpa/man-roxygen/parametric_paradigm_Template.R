#' @details The function calculates standard errors via sandwich estimator
#' and significance levels are reported taking into account quasi maximum
#' likelihood estimator (QMLE) asymptotic normality. If one wants to switch
#' from QMLE to semi-nonparametric estimator (SNPE) during hypothesis testing
#' then covariance matrix should be estimated again using bootstrap.
