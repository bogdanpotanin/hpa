#' @param tr_left numeric matrix of left (lower) truncation limits.
#' Note that \code{tr_left} rows are observations while variables are columns.
#' If \code{tr_left} and \code{tr_right} are single row matrices then the same 
#' truncation limits will be applied to all observations that are determined 
#' by the first rows of these matrices.
