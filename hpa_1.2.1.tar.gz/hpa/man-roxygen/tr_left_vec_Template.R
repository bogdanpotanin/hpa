#' @param tr_left numeric vector of left (lower) truncation limits.
