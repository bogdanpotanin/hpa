#' @details If \code{given_ind} and (or) \code{omit_ind} are numeric vectors
#' then they are insensitive to the order of elements. 
#' For example \code{given_ind = c(5, 2, 3)} is similar 
#' to \code{given_ind = c(2, 3, 5)}.
