#' @param x numeric matrix of function arguments and
#' conditional values. Note that \code{x} rows are points (observations)
#' while random vectors components (variables) are columns.
