#' @details Densities Hermite polynomial approximation approach has been
#' proposed by A. Gallant and D. W. Nychka in 1987. The main idea is to
#' approximate unknown distribution density with scaled Hermite polynomial.
#' For more information please refer to the literature listed below.
#' @references A. Gallant and D. W. Nychka (1987) <doi:10.2307/1913241>
