#' @param mean numeric vector of expected values.
