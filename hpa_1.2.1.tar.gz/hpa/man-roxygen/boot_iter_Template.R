#' @param boot_iter the number of bootstrap iterations
#' for \code{cov_type = "bootstrap"} covariance matrix estimator type.
