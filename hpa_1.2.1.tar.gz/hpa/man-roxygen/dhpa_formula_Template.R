#' @description Approximation of truncated, marginal and conditional densities,
#' moments and cumulative probabilities of multivariate distributions via
#' Hermite polynomial based approach proposed by Gallant and Nychka in 1987.
#' 
#' Density approximating function is scale adjusted product of two terms. 
#' The first one is squared multivariate polynomial of \code{pol_degrees}  
#' degrees with \code{pol_coefficients} coefficients vector. 
#' The second is product of independent normal random variables' densities with 
#' expected values and standard deviations given by \code{mean} and \code{sd} 
#' vectors correspondingly. Approximating function satisfies properties of 
#' density function thus generating a broad family of distributions.
#' Characteristics of these distributions 
#' (moments, quantiles, probabilities and so on) 
#' may provide accurate approximations to characteristic of other
#' distributions. Moreover it is usually possible to provide arbitrary close
#' approximation by the means of polynomial degrees increase.
#' @details It is possible to approximate densities 
#' \code{\link[hpa]{dhpa}}, cumulative probabilities
#' \code{\link[hpa]{phpa}}, \code{\link[hpa]{ihpa}}, moments
#' \code{\link[hpa]{ehpa}} as well as their truncated
#' \code{\link[hpa]{dtrhpa}}, \code{\link[hpa]{itrhpa}}, 
#' \code{\link[hpa]{etrhpa}} forms
#' and gradients \code{\link[hpa]{dhpaDiff}}, \code{\link[hpa]{ihpaDiff}}.
#' Note that \code{\link[hpa]{phpa}} is special of \code{\link[hpa]{ihpa}}
#' where \code{x}
#' corresponds to \code{x_upper} while \code{x_lower} is matrix of
#' negative infinity values. So  \code{\link[hpa]{phpa}} intended to approximate 
#' cumulative
#' distribution functions while \code{\link[hpa]{ihpa}} approximates 
#' probabilities that
#' random vector components will be between values determined by rows of 
#' \code{x_lower} and \code{x_upper} matrices. Further details are given below.
#' 
#' 
#' Since density approximating function is non-negative and integrates
#' to 1 it is density function for some \eqn{m}-variate 
#' random vector \eqn{\xi}. Approximating function \eqn{f_{\xi }(x)} 
#' has the following form:
#' \deqn{f_{\xi }(x) = f_{\xi }(x;\mu, \sigma, \alpha) =
#' \frac{1}{\psi }\prod\limits_{t=1}^{m}\phi 
#' ({x}_{t};{\mu }_{t},{\sigma }_{t}){{\left( \sum\limits_{{i}_{1}=0}^{{K}_{1}}
#' {...}\sum\limits_{{i}_{m}=0}^{{K}_{m}}{{{\alpha }_{({{i}_{1}},...,{{i}_{m}})
#' }}\prod\limits_{r=1}^{m}x_{r}^{{{i}_{r}}}} \right)}^{2}}}
#' \deqn{\psi =\sum\limits_{{i}_{1}=0}^{{K}_{1}}{...}\sum
#' \limits_{{i}_{m}=0}^{{K}_{m}}{\sum\limits_{{j}_{1}=0}^{{K}_{1}}
#' {...}\sum\limits_{{j}_{m}=0}^{{K}_{m}}{{{\alpha }_{({i}_{1},
#' \cdots,{i}_{m})}}{{\alpha }_{({j}_{1},\cdots,{j}_{m})}}\prod
#' \limits_{r=1}^{m}\mathcal{M}({i}_{r}+{j}_{r};{{\mu }_{r}},{\sigma }_{r})}},}
#' where:
#' 
#' \eqn{x = (x_{1},...x_{m})} - is vector of arguments i.e. rows
#'  of \code{x} matrix in \code{\link[hpa]{dhpa}}.
#'  
#' \eqn{{\alpha }_{({i}_{1},\cdots,{i}_{m})}} - is polynomial coefficient
#' corresponding to \code{pol_coefficients[k]} element. In order to investigate
#' correspondence between \code{k} and \eqn{({i}_{1},\cdots,{i}_{m})} values 
#' please see 'Examples' section below or \code{\link[hpa]{polynomialIndex}} 
#' function 'Details', 'Value' and 'Examples' sections. Note that if \eqn{m=1}
#' then \code{pol_coefficients[k]} simply corresponds to \eqn{\alpha_{k-1}}.
#' 
#' \eqn{(K_{1},...,K_{m})} - are polynomial degrees (orders) provided via
#' \code{pol_degrees} argument so \code{pol_degrees[i]} determines \eqn{K_{i}}.
#' 
#' \eqn{\phi 
#' (.;{\mu }_{t},{\sigma }_{t})} - is normal random variable density function 
#' where \eqn{\mu_{t}} and \eqn{\sigma_{t}} are mean and standard deviation 
#' determined by \code{mean[t]} and \code{sd[t]} arguments values.
#' 
#' \eqn{\mathcal{M}(q;{{\mu }_{r}},{\sigma }_{r})} - is \eqn{q}-th order
#' moment of normal random variable with mean \eqn{{\mu }_{r}} and standard
#' deviation \eqn{{\sigma }_{r}}. Note that function 
#' \code{\link[hpa]{normalMoment}} allows to calculate and differentiate normal 
#' random variable's moments.
#' 
#' \eqn{\psi} - constant term insuring that \eqn{f_{\xi }(x)} is
#' density function.
#' 
#' Therefore \code{\link[hpa]{dhpa}} allows to calculate \eqn{f_{\xi}(x)} 
#' values at points
#' determined by rows of \code{x} matrix given polynomial 
#' degrees \code{pol_degrees} (\eqn{K}) as well as \code{mean} (\eqn{\mu}), 
#' \code{sd} (\eqn{\sigma}) and \code{pol_coefficients} (\eqn{\alpha}) 
#' parameters values. Note that \code{mean}, \code{sd} and \code{pol_degrees} are 
#' \eqn{m}-variate vectors while \code{pol_coefficients} has
#' \code{prod(pol_degrees + 1)} elements.
#' 
#' Cumulative probabilities could be approximated as follows:
#' \deqn{P\left(\underline{x}_{1}\leq\xi_{1}\leq\overline{x}_{1},...,
#' \underline{x}_{m}\leq\xi_{m}\leq\overline{x}_{m}\right) = }
#' \deqn{= \bar{F}_{\xi}(\underline{x},\bar{x}) = 
#' \bar{F}_{\xi}(\underline{x},\bar{x};\mu, \sigma, \alpha) =
#' \frac{1}{\psi }
#' \prod\limits_{t=1}^{m}(\Phi ({{{\bar{x}}}_{t}};{{\mu }_{t}},
#' {{\sigma }_{t}})-\Phi ({{{\underline{x}}}_{t}};{{\mu }_{t}},
#' {{\sigma }_{t}})) * }
#' \eqn{* \sum\limits_{{{i}_{1}}=0}^{{{K}_{1}}}{...}
#' \sum\limits_{{{i}_{m}}=0}^{{{K}_{m}}}{\sum\limits_{{{j}_{1}}=0}^{{{K}_{1}}}
#' {...}\sum\limits_{{{j}_{m}}=0}^{{{K}_{m}}}
#' {{{\alpha }_{({{i}_{1}},...,{{i}_{m}})}}{{\alpha }_{({{j}_{1}},...,{{j}_{m}})
#' }}}}\prod\limits_{r=1}^{m}\mathcal{M}_{TR}\left({i}_{r}+{j}_{r};
#' \underline{x}_{r},\overline{x}_{r},\mu_{r},\sigma_{r}\right)}
#' 
#' where:
#' 
#' \eqn{\Phi 
#' (.;{\mu }_{t},{\sigma }_{t})} - is normal random variable's cumulative 
#' distribution function where \eqn{\mu_{t}} and \eqn{\sigma_{t}} are mean and 
#' standard deviation determined by \code{mean[t]} and \code{sd[t]} arguments 
#' values.
#' 
#' \eqn{\mathcal{M}_{TR}(q;
#' \underline{x}_{r},\overline{x}_{r},\mu_{r},\sigma_{r})} - is 
#' \eqn{q}-th order
#' moment of truncated (from above by \eqn{\overline{x}_{r}} and from below by
#' \eqn{\underline{x}_{r}}) 
#' normal random variable with mean \eqn{{\mu }_{r}} and standard
#' deviation \eqn{{\sigma }_{r}}. Note that function 
#' \code{\link[hpa]{truncatedNormalMoment}} allows to calculate and 
#' differentiate truncated normal random variable's moments.
#' 
#' \eqn{\overline{x} = (\overline{x}_{1},...,\overline{x}_{m})} - 
#' vector of upper integration limits
#' i.e. rows of \code{x_upper} matrix in \code{\link[hpa]{ihpa}}.
#' 
#' \eqn{\underline{x} = (\underline{x}_{1},...,\underline{x}_{m})} - 
#' vector of lower integration limits
#' i.e. rows of \code{x_lower} matrix in \code{\link[hpa]{ihpa}}.
#' 
#' Therefore \code{\link[hpa]{ihpa}} allows to calculate interval distribution 
#' function \eqn{\bar{F}_{\xi}(\underline{x},\bar{x})}
#' values at points determined by rows of \code{x_lower} (\eqn{\underline{x}})
#' and \code{x_upper} (\eqn{\overline{x}}) matrices.
#' The rest of the arguments are similar to \code{dhpa}.
#' 
#' Expected value powered product approximation is as follows:
#' 
#' \deqn{E\left( \prod\limits_{t=1}^{m}\xi_{t}^{{{k}_{t}}} \right)=
#' \frac{1}{\psi }\sum\limits_{{{i}_{1}}=0}^{{{K}_{1}}}{...}
#' \sum\limits_{{{i}_{m}}=0}^{{{K}_{m}}}
#' {\sum\limits_{{{j}_{1}}=0}^{{{K}_{1}}}{...}
#' \sum\limits_{{{j}_{m}}=0}^{{{K}_{m}}}
#' {{{\alpha }_{({{i}_{1}},...,{{i}_{m}})}}
#' {{\alpha }_{({{j}_{1}},...,{{j}_{m}})}}}}
#' \prod\limits_{r=1}^{m}\mathcal{M}({{i}_{r}}+{{j}_{r}}+{{k}_{t}};
#' {{\mu }_{r}},{{\sigma }_{r}})}
#' 
#' where \eqn{(k_{1},...,k_{m})} are integer powers determined by
#' \code{expectation_powers} argument of \code{\link[hpa]{ehpa}} so
#' \code{expectation_powers[t]} assigns \eqn{k_{t}}. Note that argument \code{x}
#' in \code{\link[hpa]{ehpa}} allows to determined conditional values.
#' 
#' Expanding polynomial degrees \eqn{(K_{1},...,K_{m})} it is possible to 
#' provide arbitrary close approximation to density of some \eqn{m}-variate 
#' random vector \eqn{\xi^{\star}}. So actually \eqn{f_{\xi}(x)}
#' approximates \eqn{f_{\xi^{\star}}(x)}. Accurate approximation requires
#' appropriate \code{mean}, \code{sd} and \code{pol_coefficients} values
#' selection. In order to get sample estimates of these parameters please apply 
#' \code{\link[hpa]{hpaML}} function.
#' 
#' In order to perform calculation for marginal distribution of some 
#' \eqn{\xi} components please provide omitted 
#' components via \code{omit_ind} argument.
#' For examples if ones assume \eqn{m=5}-variate distribution
#' and wants to deal with \eqn{1}-st, \eqn{3}-rd, and \eqn{5}-th components 
#' only i.e. \eqn{(\xi_{1},\xi_{3},\xi_{5})} then set 
#' \code{omit_ind = c(FALSE, TRUE, FALSE, TRUE, FALSE)}
#' indicating that \eqn{\xi_{2}} and \eqn{\xi_{4}} should be 'omitted' from
#' \eqn{\xi} since \eqn{2}-nd and \eqn{4}-th values of \code{omit_ind} are
#' \code{TRUE}.
#' Then \code{x} still should be \eqn{5} column matrix but 
#' values in \eqn{2}-nd and \eqn{4}-th columns will not affect 
#' calculation results. Meanwhile note that marginal distribution of \code{t}
#' components of \eqn{\xi} usually do not coincide with any marginal
#' distribution generated by \code{t}-variate density approximating function.
#' 
#' In order to perform calculation for conditional distribution i.e. given 
#' fixed values for some \eqn{\xi} components please provide these
#' components via \code{given_ind} argument.
#' For example if ones assume \eqn{m=5}-variate distribution
#' and wants to deal with \eqn{1}-st, \eqn{3}-rd, and \eqn{5}-th components 
#' given fixed values (suppose 8 and 10) for the other two components i.e. 
#' \eqn{(\xi|\xi_{2} = 8, \xi_{4} = 10)} then set 
#' \code{given_ind = c(FALSE, TRUE, FALSE, TRUE, FALSE)} and
#' \code{x[2] = 8}, \code{x[4] = 10} where for simplicity it is assumed that
#' \code{x} is single row \eqn{5} column matrix; it is possible to provide  
#' different conditional values for the same components simply setting different  
#' values to different \code{x} rows.
#' 
#' Note that it is possible to combine \code{given_ind} and \code{omit_ind}
#' arguments. However it is wrong to set both \code{given_ind[i]} and 
#' \code{omit_ind[i]} to \code{TRUE}. Also at least one value should be
#' \code{FALSE} both for \code{given_ind} and \code{omit_ind}.
#' 
#' In order to consider truncated distribution of \eqn{\xi} i.e. 
#' \eqn{\left(\xi|\overline{a}_{1}\leq\xi_{1}\leq\overline{b}_{1},
#' \cdots,\overline{a}_{m}\leq\xi_{m}\leq\overline{b}_{m}\right)}
#' please set lower (left) truncation points \eqn{\overline{a}} and 
#' upper (right) truncation points \eqn{\overline{b}} via \code{tr_left} 
#' and \code{tr_right} arguments correspondingly. Note that if lower truncation
#' points are negative infinite and upper truncation points are positive
#' infinite then \code{\link[hpa]{dtrhpa}}, \code{\link[hpa]{itrhpa}} and 
#' \code{\link[hpa]{etrhpa}} are similar to \code{\link[hpa]{dhpa}},
#' \code{\link[hpa]{ihpa}} and \code{\link[hpa]{ehpa}} correspondingly.
#' 
#' In order to calculate Jacobian of \eqn{f_{\xi }(x;\mu, \sigma, \alpha)}
#' and \eqn{\bar{F}_{\xi}(\underline{x},\bar{x};\mu, \sigma, \alpha)} w.r.t
#' all ore some particular parameters please apply \code{\link[hpa]{dhpaDiff}}
#' and \code{\link[hpa]{ihpaDiff}} functions correspondingly specifying
#' parameters of interest via \code{type} argument. If \code{x} or
#' \code{x_lower} and \code{x_upper} are single row matrices then gradients
#' will be calculated.
#' 
#' For further information please see 'Examples' section. Note that examples
#' are given separately for each function.
#' 
#' @return Functions \code{\link[hpa]{dhpa}}, \code{\link[hpa]{phpa}} and 
#' \code{\link[hpa]{dtrhpa}} return vector of probabilities of length
#' \code{nrow(x)}. 
#' 
#' Functions \code{\link[hpa]{ihpa}} and 
#' \code{\link[hpa]{itrhpa}} return vector of probabilities of length
#' \code{nrow(x_upper)}.
#' 
#' If \code{x} argument has not been provided or is a single row
#' matrix then function 
#' \code{\link[hpa]{ehpa}} returns moment value. Otherwise it returns vector of 
#' length \code{nrow(x)} containing moments values.
#' 
#' If \code{tr_left} and \code{tr_right} arguments are single row matrices then
#' function \code{\link[hpa]{etrhpa}} returns moment value.
#' Otherwise it returns vector of length
#' \code{max(nrow(tr_left), nrow(tr_right))} containing moments values.
#' 
#' Functions \code{\link[hpa]{dhpaDiff}} and \code{\link[hpa]{ihpaDiff}} 
#' return Jacobin matrix. The number
#' of columns depends on \code{type} argument. The number of rows is
#' \code{nrow(x)} for \code{\link[hpa]{dhpaDiff}} and 
#' \code{nrow(x_upper)} for
#' \code{\link[hpa]{ihpaDiff}}
#' 
#' If \code{mean} or \code{sd} are not specified they assume the default 
#' values of \eqn{m}-dimensional vectors of 0 and 1, respectively. 
#' If \code{x_lower} is not specified then it is the matrix of the 
#' same size as \code{x_upper} containing negative infinity values only. If
#' \code{expectation_powers} is not specified then it is \eqn{m}-dimensional
#' vector of 0 values.
#' 
#' Please see 'Details' section for additional information.
#' 
