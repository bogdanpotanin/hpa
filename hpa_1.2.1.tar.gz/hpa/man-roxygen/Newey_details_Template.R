#' @details Initial values for optimization routine are obtained by Newey's 
#' method (see the reference below). In order to obtain initial values
#' via least squares please, set \code{pol_elements = 0}. Initial values for
#' the outcome equation are obtained via \code{\link[hpa]{hpaBinary}} function
#' setting \code{K} to \code{selection_K}.
#' 
#' @references W. K. Newey (2009) <https://doi.org/10.1111/j.1368-423X.2008.00263.x>
#' 
