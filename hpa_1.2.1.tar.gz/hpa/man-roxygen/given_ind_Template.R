#' @param given_ind logical or numeric vector indicating whether corresponding 
#' random vector component is conditioned. By default it is a logical 
#' vector of \code{FALSE} values. If \code{give_ind[i]} equals \code{TRUE} or 
#' \code{i} then \code{i}-th column of \code{x} matrix will contain 
#' conditional values.
