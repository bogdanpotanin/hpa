#' @param K non-negative integer representing polynomial degree (order).
