#' @details This function maximizes (quasi) log-likelihood function 
#' via \code{\link[stats]{optim}} function setting its \code{method} 
#' argument to "BFGS". If \code{opt_type = "GA"} then genetic
#' algorithm from \code{\link[GA]{ga}} function
#' will be additionally (after \code{\link[stats]{optim}} putting its
#' solution (\code{par}) into \code{suggestions} matrix) applied in order to 
#' perform global optimization. Note that global optimization takes
#' much more time (usually minutes but sometimes hours or even days). 
#' The number of iterations and population size of the genetic algorithm
#' will grow linearly along with the number of estimated parameters. 
#' If it seems that global maximum has not been found then it
#' is possible to continue the search restarting the function setting 
#' its input argument \code{x0} to \code{x1} output value. Note that
#' if \code{cov_type = "bootstrap"} then \code{\link[GA]{ga}}
#' function will not be used for bootstrap iterations since it
#' may be extremely time consuming.
