#' @details All variables mentioned in \code{selection} and 
#' \code{outcome} should be numeric vectors.
