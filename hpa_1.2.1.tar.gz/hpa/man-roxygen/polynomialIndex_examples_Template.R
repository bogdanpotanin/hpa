#' @examples
#' ## Get polynomial indexes matrix for the polynomial 
#' ## which degrees are (1, 3, 5)
#' 
#' polynomialIndex(c(1, 3, 5))
#' \donttest{
#' ## Consider multivariate polynomial of degrees (2, 1) such that coefficients
#' ## for elements which powers sum is even are 2 and for those which powers sum
#' ## is odd are 5. So the polynomial is 2+5x2+5x1+2x1x2+2x1^2+5x1^2x2 where
#' ## x1 and x2 are polynomial variables.
#' 
#' # Create variable to store polynomial degrees
#' pol_degrees <- c(2, 1)
#' 
#' # Let's represent its powers (not coefficients) in a matrix form
#' pol_matrix <- polynomialIndex(pol_degrees)
#' 
#' # Calculate polynomial elements' powers sums
#' pol_powers_sum <- pol_matrix[1, ] + pol_matrix[2, ]
#' 
#' # Let's create polynomial coefficients vector filling it
#' # with NA values
#' pol_coefficients <- rep(NA, (pol_degrees[1] + 1) * (pol_degrees[2] + 1))
#' 
#' # Now let's fill coefficients vector with correct values
#' pol_coefficients[pol_powers_sum %% 2 == 0] <- 2
#' pol_coefficients[pol_powers_sum %% 2 != 0] <- 5
#' 
#' # Finally, let's check that correspondence is correct
#' printPolynomial(pol_degrees, pol_coefficients)
#' }
