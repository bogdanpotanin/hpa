#' @param knots sorted in ascending order numeric vector representing
#' knots of the spline.
