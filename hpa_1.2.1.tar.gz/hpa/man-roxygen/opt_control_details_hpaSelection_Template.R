#' @details Let's denote by \code{n_reg} the number of regressors
#' included into the \code{selection} and \code{outcome} formulas.
#' The arguments \code{popSize} and \code{maxiter} of
#' \code{\link[GA]{ga}} function have been set proportional to the number of
#' estimated polynomial coefficients and independent variables:
#' \itemize{
#' \item \code{popSize = 10 + 5 * (z_K + 1) * (y_K + 1) + 2 * n_reg}
#' \item \code{maxiter = 50 * (z_K + 1) * (y_K + 1) + 10 * n_reg}}
