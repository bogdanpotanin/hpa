#' @examples
#' ## Examples demonstrating qhpa function application.
#' 
#' ## Sub-example 1 - univariate distribution
#' ## Consider random variable X
#' 
#' # Distribution parameters
#' mean <- 1
#' sd <- 2
#' pol_degrees <- 2
#' pol_coefficients <- c(1, 0.1, -0.01)
#'
#' # The level of quantile
#' p <- 0.7
#' 
#' # Calculate quantile of X
#' qhpa(p = p,
#'      pol_coefficients = pol_coefficients, 
#'      pol_degrees = pol_degrees,
#'      mean = mean, sd = sd)
#'      
#' ## Sub-example 2 - marginal distribution
#' ## Consider random vector (X1, X2) and quantile of X1
#' 
#' # Distribution parameters
#' mean <- c(1, 1.2)
#' sd <- c(2, 3)
#' pol_degrees <- c(2, 2)
#' pol_coefficients <- c(1, 0.1, -0.01, 0.2, 0.012, 
#'                       0.0013, 0.0042, 0.00025, 0)
#'
#' # The level of quantile
#' p <- 0.7
#' 
#' # Calculate quantile of X1
#' qhpa(p = p,
#'      pol_coefficients = pol_coefficients, 
#'      pol_degrees = pol_degrees,
#'      mean = mean, sd = sd,
#'      omit_ind = 2)                          # set omitted variable index
#'      
#' ## Sub-example 3 - marginal and conditional distribution
#' ## Consider random vector (X1, X2, X3) and 
#' 
#' ## quantiles of X1|X3 and X1|(X2,X3)
#' mean <- c(1, 1.2, 0.9)
#' sd <- c(2, 3, 2.5)
#' pol_degrees <- c(1, 1, 1)
#' pol_coefficients <- c(1, 0.1, -0.01, 0.2, 0.012, 
#'                       0.0013, 0.0042, 0.00025)
#'
#' # The level of quantile
#' p <- 0.7
#' 
#' # Calculate quantile of X1|X3 = 0.2
#' qhpa(p = p,
#'      x = matrix(c(NA, NA, 0.2), nrow = 1),  # set any values to
#'                                             # unconditioned and 
#'                                             # omitted components
#'      pol_coefficients = pol_coefficients, 
#'      pol_degrees = pol_degrees,
#'      mean = mean, sd = sd,
#'      omit_ind = 2,                          # set omitted variable index
#'      given_ind = 3)                         # set conditioned variable index
#'      
#' # Calculate quantile of X1|(X2 = 0.5, X3 = 0.2)
#' qhpa(p = p,
#'      x = matrix(c(NA, 0.5, 0.2), nrow = 1), # set any values to 
#'                                             # unconditioned and 
#'                                             # omitted components
#'      pol_coefficients = pol_coefficients, 
#'      pol_degrees = pol_degrees,
#'      mean = mean, sd = sd,
#'      given_ind = c(2, 3))                   # set conditioned
#'                                             # variables indexes
#'         
