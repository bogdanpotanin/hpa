#' @param cdf_difference non-negative numeric matrix of 
#' precalculated \code{cdf_upper-cdf_lower} values.
