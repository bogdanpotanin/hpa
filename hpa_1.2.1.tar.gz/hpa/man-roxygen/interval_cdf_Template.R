#' @details Interval distribution function represents probability that random
#'  vector components will be greater than values given in \code{x_lower} and 
#'  lower than values that are in \code{x_upper}.
