#' @examples
#' ## Consider normal distribution with mean 3 and standard deviation 5.
#' ## Calculate its cumulative distribution function at points 2 and 3.
#'
#' # Create vector of points
#' my_points <- c(2, 3)
#' 
#' # Calculate cdf at these points
#' pnorm_parallel(my_points, 3, 5)
