#' @details All variables mentioned in \code{formula} should be numeric vectors.
