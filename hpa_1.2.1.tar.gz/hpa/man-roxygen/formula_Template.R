#' @param formula an object of class "formula" 
#' (or one that can be coerced to that class):
#' a symbolic description of the model to be fitted.
#' All variables in \code{formula} should be numeric 
#' vectors of the same length.
