#' @param coef_fixed logical value indicating whether binary 
#' equation first independent variable coefficient should be fixed 
#' (\code{TRUE}) or estimated (\code{FALSE}).
