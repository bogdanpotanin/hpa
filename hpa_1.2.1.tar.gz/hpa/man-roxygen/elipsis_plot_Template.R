#' @param ... further arguments to be passed to \code{\link[base]{plot}}
#' function.
