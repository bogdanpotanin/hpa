#' @param constant_fixed numeric value for binary choice 
#' equation constant parameter. Set it to \code{NA} (default) if this 
#' parameter should be estimated rather than fixed.
