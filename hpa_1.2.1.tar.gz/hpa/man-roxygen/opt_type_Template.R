#' @param opt_type string value determining the type of the optimization
#' routine to be applied. The default is \code{"optim"} meaning that BFGS method
#' from the \code{\link[stats]{optim}} function will be applied.
#' If \code{opt_type = "GA"} then \code{\link[GA]{ga}} function will be
#' additionally applied.
