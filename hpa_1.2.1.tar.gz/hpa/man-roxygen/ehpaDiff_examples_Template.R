#' @examples
#' ## Example demonstrating ehpaDiff function application.
#' ## Let's approximate some three random variables (X1, X2, X3) expectation
#' ## of the form E((X1 ^ 3) * (x2 ^ 1) * (X3 ^ 2)) and calculate the gradient
#' 
#' # Distribution parameters
#' mean <- c(1.1, 1.2, 1.3)
#' sd <- c(2.1, 2.2, 2.3)
#' pol_degrees <- c(1, 2, 3)
#' pol_coefficients_n <- prod(pol_degrees + 1)
#' pol_coefficients <- rep(1, pol_coefficients_n)
#' 
#' # Set powers for expectation
#' expectation_powers <- c(3, 1, 2)
#' 
#' # Calculate expectation approximation gradient 
#' # respect to all parameters
#' ehpaDiff(pol_coefficients = pol_coefficients, 
#'          pol_degrees = pol_degrees,
#'          mean = mean, sd = sd,
#'          expectation_powers = expectation_powers,
#'          type = "all")
#'
#' # Let's calculate gradient of E(X1 ^ 3 | (X2 = 1, X3 = 2))
#' x <- c(0, 1, 2)                  # x[1] may be arbitrary (not NA) values
#' expectation_powers <- c(3, 0, 0) # expectation_powers[2:3] may be 
#'                                  # arbitrary (not NA) values
#' given_ind <- c(2, 3)
#' ehpaDiff(x = x,
#'          pol_coefficients = pol_coefficients, 
#'          pol_degrees = pol_degrees,
#'          mean = mean, sd = sd,
#'          given_ind = given_ind,
#'          expectation_powers = expectation_powers,
#'          type = "all")
