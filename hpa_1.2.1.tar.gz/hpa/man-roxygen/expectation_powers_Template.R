#' @param expectation_powers integer vector of random vector components powers.
