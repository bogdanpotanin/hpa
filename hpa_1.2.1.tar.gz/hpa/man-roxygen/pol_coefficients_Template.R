#' @param pol_coefficients numeric vector of polynomial coefficients.
