#' @param omit_ind logical or numeric vector indicating whether corresponding
#' random component is omitted. By default it is a logical vector 
#' of \code{FALSE} values. If \code{omit_ind[i]} equals \code{TRUE} or \code{i} 
#' then values in \code{i}-th column of \code{x} matrix will be ignored.
