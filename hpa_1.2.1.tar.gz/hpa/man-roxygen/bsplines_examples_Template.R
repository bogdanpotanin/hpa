#' @examples
#' # Let's generate all b-splines of degree 3 with knots 
#' # vector (-2.1, 1.5, 1.5, 2.2, 3.7, 4.2, 5)
#' b <- bsplineGenerate(knots = c(-2.1, 1.5, 1.5, 2.2, 3.7, 4.2, 5), 
#'                      degree = 3)
#' 
#' # Get the first of these b-splines
#' b[[1]]
#' 
#' # Take a linear combination of these splines with 
#' # weights 1.6, -1.2 and 3.2.
#' b_comb <- bsplineComb(splines = b, weights = c(1.6, -1.2, 3.2))
#' 
#' # Estimate this spline value at points (-3, 0.7, 2.5, 3.8, 10)
#' b_values <- bsplineEstimate(x = c(-3, 0.7, 2.5, 3.8, 10),  
#'                             knots = b_comb$knots, 
#'                             m = b_comb$m)
#'\donttest{
#' # Visualize the spline
#' s <- seq(from = 0, to = 5, length = 1000)
#' b_values_s <- bsplineEstimate(x = s,  
#'                               knots = b_comb$knots, 
#'                               m = b_comb$m)
#' plot(s, b_values_s)
#'}
