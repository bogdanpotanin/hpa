#' @param m numeric matrix which rows correspond to spline intervals
#' while columns represent variables powers. Therefore the element 
#' in i-th row and j-th column represents the coefficient associated with
#' the variable that 1) belongs to the i-th interval i.e. between i-th and
#' (i + 1)-th knots 2) raised to the power of (j - 1).
