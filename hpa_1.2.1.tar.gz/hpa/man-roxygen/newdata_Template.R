#' @param newdata An optional data frame (for \link[hpa]{hpaBinary} and
#' \link[hpa]{hpaSelection}) or numeric matrix (for \link[hpa]{hpaML})
#' in which to look for variables with which to predict. If omitted,
#' the original data frame (matrix) used.
