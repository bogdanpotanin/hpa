#' @details The arguments \code{popSize} and \code{maxiter} of
#' \code{\link[GA]{ga}} function have been set proportional to the number of
#' estimated polynomial coefficients:
#' \itemize{
#' \item \code{popSize = 10 + (prod(pol_degrees + 1) - 1) * 2}.
#' \item \code{maxiter = 50 * (prod(pol_degrees + 1))}}
