#' @param cov_type character determining the type of covariance matrix to be
#' returned and used for summary. If \code{cov_type = "hessian"} then negative
#' inverse of Hessian matrix will be applied. If \code{cov_type = "gop"} then
#' inverse of Jacobian outer products will be used.
#' If \code{cov_type = "sandwich"} (default) then sandwich covariance matrix
#' estimator will be applied. If \code{cov_type = "bootstrap"} then bootstrap
#' with \code{boot_iter} iterations will be used.
#' If \code{cov_type = "hessianFD"} or \code{cov_type = "sandwichFD"} then
#' (probably) more accurate but computationally demanding central difference 
#' Hessian approximation will be calculated for the inverse Hessian and 
#' sandwich estimators correspondingly. Central differences are computed via
#' analytically provided gradient. This Hessian matrix estimation approach
#' seems to be less accurate than BFGS approximation if polynomial order
#' is high (usually greater then 5).
