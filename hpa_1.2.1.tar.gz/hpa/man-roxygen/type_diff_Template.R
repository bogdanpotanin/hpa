#' @param type determines the partial derivatives to be included into the
#' gradient. If \code{type="pol_coefficients"} then gradient will contain 
#' partial derivatives respect to polynomial coefficients listed in the
#' same order as \code{pol_coefficients}. Other available types are 
#' \code{type = "mean"} and \code{type = "sd"}.
#' For function \code{\link[hpa]{dhpaDiff}} it is possible to take
#' gradient respect to the x points setting \code{type="x"}.
#' For function \code{\link[hpa]{ihpaDiff}} it is possible to take
#' gradient respect to the x lower and upper points setting 
#' \code{type = "x_lower"} or \code{type = "upper"} correspondingly.
#' In order to get full gradient please set \code{type="all"}.
