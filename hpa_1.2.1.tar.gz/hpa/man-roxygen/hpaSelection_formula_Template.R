#' @details Let's use notations introduced in \code{\link[hpa]{dhpa}} 'Details' 
#' section. Function \code{\link[hpa]{hpaSelection}} maximizes the following
#' quasi log-likelihood function:
#' \deqn{\ln L(\gamma, \beta, \alpha, \mu, \sigma; x) = 
#' \sum\limits_{i:z_{i}=1} 
#' \ln\left(\overline{F}_{\left(\xi_{1}|\xi_{2}=y_{i}-x_{i}^{o}\beta\right)}
#' \left(-\gamma x_{i}^{s}, \infty;\alpha, \mu, \sigma\right)\right)
#' f_{\xi_{2}}\left(y_{i}-x_{i}^{o}\beta\right)+}
#' \deqn{
#' +\sum\limits_{i:z_{i}=0} 
#' \ln\left(\overline{F}_{\xi}
#' (-\infty, -x_{i}^{s}\gamma;\alpha, \mu, \sigma)\right),}
#' 
#' where (in addition to previously defined notations):
#' 
#' \eqn{x_{i}^{s}} - is row vector of selection equation regressors derived  
#' from \code{data} according to \code{selection} formula.
#' 
#' \eqn{x_{i}^{o}} - is row vector of outcome equation regressors derived  
#' from \code{data} according to \code{outcome} formula.
#' 
#' \eqn{\gamma} - is column vector of selection equation 
#' regression coefficients (constant will not be added by default).
#' 
#' \eqn{\beta} - is column vector of outcome equation 
#' regression coefficients (constant will not be added by default).
#' 
#' \eqn{z_{i}} - binary (0 or 1) dependent variable defined 
#' in \code{selection} formula.
#' 
#' \eqn{y_{i}} - continuous dependent variable defined 
#' in \code{outcome} formula.
#' 
#' Note that \eqn{\xi} is two dimensional and \code{selection_K} corresponds
#' to \eqn{K_{1}} while \code{outcome_K} determines \eqn{K_{2}}.
#' 
#' The first polynomial coefficient (zero powers) 
#' set to 1 for identification purposes i.e. \eqn{\alpha_{0}=1}.
#' 
#' Rows in \code{data} corresponding to variables mentioned in \code{selection}
#' and \code{outcome} formulas which have at least one \code{NA}
#' value will be ignored. The exception is continues dependent variable 
#' \eqn{y} which may have \code{NA} values for observation where \eqn{z_{i}=0}.
