#' @param cdf_upper non-negative numeric matrix of
#' precalculated normal cumulative distribution functions
#' with mean \code{mean} and standard deviation
#' \code{sd} at points given by \code{x_upper}.
