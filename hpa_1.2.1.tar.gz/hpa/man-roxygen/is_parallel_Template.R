#' @param is_parallel if \code{TRUE} then multiple cores will be
#' used for some calculations. It usually provides speed advantage for
#' large enough samples (about more than 1000 observations).
