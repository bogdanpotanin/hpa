#' @param outcome_K non-negative integer representing polynomial 
#' degree related to outcome equation.
