#' @param degree positive integer representing degree of the spline.
