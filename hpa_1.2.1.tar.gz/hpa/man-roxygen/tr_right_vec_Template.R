#' @param tr_right numeric vector of right (upper) truncation limits.
