#' @param x numeric matrix of interval distribution function arguments.
#' Note that \code{x} rows are observations while variables are columns.
