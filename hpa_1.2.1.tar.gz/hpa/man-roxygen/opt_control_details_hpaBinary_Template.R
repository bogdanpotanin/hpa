#' @details Let's denote by \code{n_reg} the number of regressors
#' included into the \code{formula}.
#' The arguments \code{popSize} and \code{maxiter} of
#' \code{\link[GA]{ga}} function have been set proportional to the number of
#' estimated polynomial coefficients and independent variables:
#' \itemize{
#' \item \code{popSize = 10 + 5 * (K + 1) + 2 * n_reg}
#' \item \code{maxiter = 50 * (1 + K) + 10 * n_reg}}
