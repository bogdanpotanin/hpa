#' @param x0 numeric vector of optimization routine initial values.
#' Note that \code{x0 = c(pol_coefficients[-1], mean, sd, z_coef, y_coef)}.
