#' @param pdf_lower non-negative numeric matrix of precalculated normal
#' density functions with mean \code{mean} and standard deviation \code{sd} at
#' points given by \code{x_lower}.
