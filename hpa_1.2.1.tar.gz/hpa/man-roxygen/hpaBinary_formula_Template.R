#' @details Let's use notations introduced in \code{\link[hpa]{dhpa}} 'Details' 
#' section. Function \code{\link[hpa]{hpaBinary}} maximizes the following
#' quasi log-likelihood function:
#' \deqn{\ln L(\gamma_{0}, \gamma, \alpha, \mu, \sigma; x) = 
#' \sum\limits_{i:z_{i}=1} 
#' \ln\left(\overline{F}_{\xi}
#' (-(\gamma_{0}+\gamma x_{i}), \infty;\alpha, \mu, \sigma)\right) +}
#' \deqn{
#' +\sum\limits_{i:z_{i}=0} 
#' \ln\left(\overline{F}_{\xi}
#' (-\infty, -(\gamma_{0} + x_{i}\gamma);\alpha, \mu, \sigma)\right),}
#' 
#' where (in addition to previously defined notations):
#' 
#' \eqn{x_{i}} - is row vector of regressors derived from \code{data} 
#' according to \code{formula}.
#' 
#' \eqn{\gamma} - is column vector of regression coefficients.
#' 
#' \eqn{\gamma_{0}} - constant.
#' 
#' \eqn{z_{i}} - binary (0 or 1) dependent variable defined in \code{formula}.
#' 
#' Note that \eqn{\xi} is one dimensional and \code{K} corresponds
#' to \eqn{K=K_{1}}.
#' 
#' The first polynomial coefficient (zero powers) 
#' set to 1 for identification purposes i.e. \eqn{\alpha_{0}=1}.
#' 
#' If \code{coef_fixed} is \code{TRUE} then the coefficient for the 
#' first independent variable in \code{formula} will be fixed to 1 i.e.
#' \eqn{\gamma_{1}=1}.
#' 
#' If \code{mean_fixed} is not \code{NA} then \eqn{\mu}=\code{mean_fixed}
#' fixed.
#' 
#' If \code{sd_fixed} is not \code{NA} then \eqn{\sigma}=\code{mean_fixed}
#' fixed. However if \code{is_x0_probit = TRUE} then parameter \eqn{\sigma} will 
#' be scale adjusted in order to provide better initial point for optimization 
#' routine. Please, extract \eqn{\sigma} adjusted value from the function's 
#' output list. The same is for \code{mean_fixed}.
#' 
#' Rows in \code{data} corresponding to variables mentioned in \code{formula}
#' which have at least one \code{NA} value will be ignored.
