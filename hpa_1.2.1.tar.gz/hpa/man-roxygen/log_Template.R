#' @param log logical; if \code{TRUE} then probabilities p are given as log(p)
#' or derivatives will be given respect to log(p).
