#' @param data numeric matrix which rows are realizations of independent 
#' identically distributed random vectors while columns correspond to
#' variables.
