#' @param sd positive numeric vector of standard deviations.
