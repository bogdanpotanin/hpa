#' @details Note that parameter \code{k} value automatically converts 
#' to integer. So passing non-integer \code{k} value will not cause 
#' any errors but the calculations will be performed for rounded 
#' \code{k} value only.
