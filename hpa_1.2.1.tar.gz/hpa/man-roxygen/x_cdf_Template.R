#' @param x numeric matrix of cumulative distribution function arguments.
#' Note that \code{x} rows are observations while variables are columns.
