#' @details If \code{opt_type = "GA"} then \code{opt_control} should be the
#' list containing the values to be passed to \code{\link[GA]{ga}}
#' function. It is possible to pass arguments \code{lower}, \code{upper},
#' \code{popSize}, \code{pcrossover}, \code{pmutation}, \code{elitism},
#' \code{maxiter}, \code{suggestions}, \code{optim}, \code{optimArgs},
#' \code{seed} and \code{monitor}. 
#' Note that it is possible to set \code{population},
#' \code{selection}, \code{crossover} and \code{mutation} arguments changing
#' \code{\link[GA]{ga}} default parameters via \code{\link[GA]{gaControl}} 
#' function. These arguments information reported in \code{\link[GA]{ga}}.
#' In order to provide manual values for \code{lower} and \code{upper} bounds
#' please follow parameters ordering mentioned above for the
#' \code{x0} argument. If these bounds are not provided manually then
#' they (except those related to the polynomial coefficients)
#' will depend on the estimates obtained
#' by local optimization via \code{\link[stats]{optim}} function
#' (this estimates will be in the middle
#' between \code{lower} and \code{upper}).
#' Specifically for each sd parameter \code{lower} (\code{upper}) bound
#' is 5 times lower (higher) than this
#' parameter \code{\link[stats]{optim}} estimate.
#' For each mean and regression coefficient parameter its lower and 
#' upper bounds deviate from corresponding \code{\link[stats]{optim}} estimate
#' by two absolute values of this estimate.
#' Finally, lower and upper bounds for each polynomial
#' coefficient are \code{-10} and \code{10} correspondingly (do not depend
#' on their \code{\link[stats]{optim}} estimates).
#' 
#' The following arguments are differ from their defaults in
#' \code{\link[GA]{ga}}:
#' \itemize{
#' \item \code{pmutation = 0.2},
#' \item \code{optim = TRUE},
#' \item \code{optimArgs =
#' list("method" = "Nelder-Mead", "poptim" = 0.2, "pressel" = 0.5)},
#' \item \code{seed = 8},
#' \item \code{elitism = 2 + round(popSize * 0.1)}.}
