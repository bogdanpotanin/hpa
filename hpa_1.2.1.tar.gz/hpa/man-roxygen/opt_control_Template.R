#' @param opt_control a list containing arguments to be passed to the
#' optimization routine depending on \code{opt_type} argument value.
#' Please see details to get additional information.
