#' @examples
#' ## Examples demonstrating dhsa and ehsa functions application.
#' 
#' # Generate a b-splines
#' b <- bsplineGenerate(knots = c(-2.1, 1.5, 1.5, 2.2, 3.7, 4.2, 5),
#'                      degree = 3)
#'                       
#' # Combine b-splines into a spline
#' spline <- bsplineComb(splines = b, weights = c(1.6, -1.2, 3.2))
#' 
#' # Assign parameters using the spline created above
#' knots <- spline$knots
#' m <- spline$m
#' mean <- 1
#' sd <- 2
#' 
#' # Estimate the density at particular points
#' x <- c(2, 3.7, 8)
#' dhsa(x, 
#'      m = m, knots = knots,
#'      mean = mean, sd = sd)
#'      
#' # Calculate expected value
#' ehsa(m = m, knots = knots,
#'      mean = mean, sd = sd,
#'      power = 1) 
#'      
#' # Evaluate the third moment
#' ehsa(m = m, knots = knots,
#'      mean = mean, sd = sd,
#'      power = 3) 
