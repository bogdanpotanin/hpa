#' @param x_upper numeric matrix of upper integration limits.
#' Note that \code{x_upper} rows are observations while variables
#' are columns.
