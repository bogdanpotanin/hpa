#' @param diff_type string value indicating the type of the argument
#' the moment should be differentiated respect to.
#' Default value is \code{"NO"} so the moments itself will be returned. 
#' Alternative values are \code{"mean"} and \code{"sd"}. Also 
#' \code{"x_lower"} and \code{"x_upper"} values are available for 
#' \code{\link[hpa]{truncatedNormalMoment}}.
