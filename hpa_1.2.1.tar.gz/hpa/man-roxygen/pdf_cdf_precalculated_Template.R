#' @details If there is precalculated density or cumulative distribution
#' functions at standardized truncation points (subtract \code{mean} 
#' and then divide by \code{sd}) then it is possible to provide
#' them through \code{pdf_lower}, \code{pdf_upper}, 
#' \code{cdf_lower} and \code{cdf_upper} arguments in
#' order to decrease number of calculations.
