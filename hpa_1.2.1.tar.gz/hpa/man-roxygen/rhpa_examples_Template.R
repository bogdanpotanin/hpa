#' @examples
#' ## Examples demonstrating rhpa function application.
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # Distribution parameters
#' mean <- 1
#' sd <- 2
#' pol_degrees <- 2
#' pol_coefficients <- c(1, 0.1, -0.01)
#' 
#' # Simulate two observations from this distribution
#' rhpa(n = 2,
#'      pol_coefficients = pol_coefficients, 
#'      pol_degrees = pol_degrees,
#'      mean = mean, sd = sd)
#'         
